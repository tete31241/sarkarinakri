# Security Specification for SarkariTrack

## Data Invariants
1. A Job posting must have a unique slug.
2. A Job posting must have a valid category.
3. Only authenticated admins can create, update, or delete job postings.
4. Anyone (including unauthenticated users) can read job postings and categories.
5. `createdAt` must be set to `request.time` on creation and be immutable.
6. `updatedAt` must be updated to `request.time` on every update.

## The Dirty Dozen Payloads
1. Create a job as an unauthenticated user. (Expected: DENIED)
2. Create a job as a non-admin authenticated user. (Expected: DENIED)
3. Update a job's `createdAt` field. (Expected: DENIED)
4. Create a job with a 2MB content string (Limit 1MB). (Expected: DENIED)
5. Create a job without a required field like `title`. (Expected: DENIED)
6. Inject a script tag into the `title` field. (Expected: DENIED if regex used)
7. Update a job's `slug` to something already existing (Handled by app, but rules should ideally prevent if possible, though slugs are doc IDs here).
8. Delete a job as a non-admin. (Expected: DENIED)
9. Create a job with a future `createdAt`. (Expected: DENIED)
10. Update a job with a `status` field not in the schema. (Expected: DENIED via strict keys)
11. Read jobs without being signed in. (Expected: ALLOWED - for public portal)
12. Bulk download jobs without limits (Rules can't fully prevent, but we enforce `id` checks).

## Test Runner (Draft)
A `firestore.rules.test.ts` would verify these. For now, I'll proceed to rule generation.
