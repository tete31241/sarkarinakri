/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, query, where, getDocs, limit } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import { Job, OperationType } from '../types';
import { Calendar, Briefcase, IndianRupee, MapPin, ExternalLink, FileText, ChevronLeft, Download, Send, MessageSquare } from 'lucide-react';

export default function JobDetail() {
  const { slug } = useParams();
  const [job, setJob] = React.useState<Job | null>(null);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    async function fetchJob() {
      if (!slug) return;
      try {
        const q = query(collection(db, 'jobs'), where('slug', '==', slug), limit(1));
        const snapshot = await getDocs(q);
        if (!snapshot.empty) {
          setJob({ id: snapshot.docs[0].id, ...snapshot.docs[0].data() } as Job);
        }
        setLoading(false);
      } catch (error) {
        handleFirestoreError(error, OperationType.GET, `jobs/${slug}`);
      }
    }
    fetchJob();
  }, [slug]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!job) {
    return (
      <div className="text-center py-20 bg-white rounded-xl shadow-sm">
        <h2 className="text-2xl font-bold font-sora text-primary">Notification Not Found</h2>
        <p className="mt-2 text-gray-500">The post you are looking for might have been removed.</p>
        <Link to="/" className="mt-6 inline-block bg-primary text-white px-6 py-2 rounded-lg font-bold">Back to Home</Link>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      <Link to="/" className="inline-flex items-center text-xs font-bold text-gray-500 hover:text-accent transition uppercase tracking-wider">
        <ChevronLeft className="h-4 w-4 mr-1" /> Back to Dashboard
      </Link>

      <div className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-200">
        {/* Header Section */}
        <div className="bg-primary text-white p-6 md:p-8">
          <div className="flex items-center gap-2 mb-3">
            <span className="bg-accent px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest">{job.category}</span>
            {job.isTrending && <span className="bg-accent-gold text-primary px-2.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-widest">Trending</span>}
          </div>
          <h1 className="text-2xl md:text-3xl font-sora font-extrabold leading-tight">{job.title}</h1>
          <div className="flex flex-wrap gap-4 mt-6 text-white/70 text-xs font-semibold uppercase tracking-wide">
            <span className="flex items-center gap-1.5"><Briefcase className="h-4 w-4 text-accent-gold" /> {job.organization}</span>
            {job.state && <span className="flex items-center gap-1.5"><MapPin className="h-4 w-4 text-accent-gold" /> {job.state}</span>}
            <span className="flex items-center gap-1.5"><Calendar className="h-4 w-4 text-accent-gold" /> Posted: {new Date(job.createdAt).toLocaleDateString()}</span>
          </div>
        </div>

        {/* Content Section */}
        <div className="p-6 md:p-8 space-y-10">
          
          {/* Info Table */}
          <section>
            <div className="border-l-4 border-accent pl-3 mb-4">
              <h2 className="font-sora font-extrabold text-primary text-sm uppercase tracking-wider">Crucial Information</h2>
            </div>
            <div className="overflow-x-auto rounded-lg border border-gray-100">
              <table className="w-full text-left border-collapse bg-gray-50/50">
                <tbody className="text-[13px]">
                  <tr className="border-b border-gray-100"><td className="p-3 font-bold text-gray-500 w-1/3">Post Name</td><td className="p-3 font-semibold text-primary">{job.title}</td></tr>
                  <tr className="border-b border-gray-100"><td className="p-3 font-bold text-gray-500">Vacancies</td><td className="p-3 font-extrabold text-green-600">{job.vacancies} Posts</td></tr>
                  <tr className="border-b border-gray-100"><td className="p-3 font-bold text-gray-500">Educational Qualification</td><td className="p-3 font-semibold">{job.qualification}</td></tr>
                  <tr className="border-b border-gray-100"><td className="p-3 font-bold text-gray-500">Pay Scale / Salary</td><td className="p-3 font-semibold">{job.salary}</td></tr>
                  <tr className="border-b border-gray-100"><td className="p-3 font-bold text-gray-500">Age Limit</td><td className="p-3 font-semibold">{job.ageLimit}</td></tr>
                </tbody>
              </table>
            </div>
          </section>

          {/* Details */}
          <section>
            <div className="border-l-4 border-accent pl-3 mb-4">
              <h2 className="font-sora font-extrabold text-primary text-sm uppercase tracking-wider">Detailed Description</h2>
            </div>
            <div 
              className="prose prose-sm max-w-none text-gray-700 leading-relaxed font-medium"
              dangerouslySetInnerHTML={{ __html: job.content }}
            />
          </section>

          {/* Important Dates & Links */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-6 border-t border-gray-100">
             <section className="space-y-4">
                <h3 className="font-sora font-bold text-sm text-primary flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-accent" /> Important Recruitment Dates
                </h3>
                <div className="space-y-2 text-sm bg-gray-50 p-4 rounded-xl border border-gray-100">
                  <div className="flex justify-between pb-2 border-b border-gray-200">
                    <span className="text-gray-500 font-medium">Application Start:</span>
                    <span className="font-bold text-primary">{job.importantDates.start || 'TBA'}</span>
                  </div>
                  <div className="flex justify-between py-2 border-b border-gray-200">
                    <span className="text-gray-500 font-medium">Application Close:</span>
                    <span className="font-bold text-red-600 underline decoration-2 underline-offset-4">{job.importantDates.end || 'TBA'}</span>
                  </div>
                  <div className="flex justify-between pt-2">
                    <span className="text-gray-500 font-medium">Exam Date:</span>
                    <span className="font-bold text-primary">{job.importantDates.examDate || 'TBA'}</span>
                  </div>
                </div>
             </section>

             <section className="space-y-4">
                <h3 className="font-sora font-bold text-sm text-primary flex items-center gap-2">
                  <ExternalLink className="h-5 w-5 text-accent" /> Official Links
                </h3>
                <div className="flex flex-col gap-3">
                  {job.links.applyLink && (
                    <a href={job.links.applyLink} target="_blank" rel="noopener" className="flex items-center justify-center gap-2 bg-accent text-white font-extrabold py-3.5 rounded-xl hover:bg-red-700 transition shadow-lg shadow-red-100 uppercase tracking-wider text-xs">
                      📝 Apply Online Now <ExternalLink className="h-4 w-4" />
                    </a>
                  )}
                  {job.links.pdfLink && (
                    <a href={job.links.pdfLink} target="_blank" rel="noopener" className="flex items-center justify-center gap-2 bg-primary text-white font-extrabold py-3 rounded-xl hover:opacity-90 transition uppercase tracking-wider text-xs">
                      📄 Notification PDF <Download className="h-4 w-4" />
                    </a>
                  )}
                </div>
             </section>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 border border-gray-200 shadow-sm text-center space-y-4">
        <p className="text-sm font-bold text-primary font-sora">Never miss an update again!</p>
        <div className="flex flex-col sm:flex-row justify-center gap-3">
          <a href="#" className="flex items-center justify-center gap-2 bg-[#25D366] text-white px-6 py-2.5 rounded-full text-xs font-bold shadow-md hover:bg-[#128C7E] transition">
            <MessageSquare className="h-4 w-4" /> WhatsApp Channel
          </a>
          <a href="#" className="flex items-center justify-center gap-2 bg-[#0088cc] text-white px-6 py-2.5 rounded-full text-xs font-bold shadow-md hover:bg-[#0077b5] transition">
            <Send className="h-4 w-4" /> Telegram Group
          </a>
        </div>
      </div>
    </div>
  );
}
