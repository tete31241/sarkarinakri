/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import { Job, OperationType } from '../types';
import { ChevronRight, Award, FileText, Send, MessageSquare, TrendingUp } from 'lucide-react';

export default function CategoryPage() {
  const { catSlug } = useParams();
  const [jobs, setJobs] = React.useState<Job[]>([]);
  const [loading, setLoading] = React.useState(true);

  const categoryMap: { [key: string]: string } = {
    'central-govt': 'Central Jobs',
    'state-govt': 'State Govt',
    'banking': 'Banking',
    'railway': 'Railway',
    'ssc': 'SSC',
    'upsc': 'UPSC',
    'latest-jobs': 'Latest Jobs',
    'admit-card': 'Admit Card',
    'result': 'Result',
    'answer-key': 'Answer Key',
    'syllabus': 'Syllabus',
    'upcoming-exam': 'Upcoming Exam'
  };

  const categoryName = categoryMap[catSlug || ''] || 'Latest Jobs';

  React.useEffect(() => {
    const q = query(
      collection(db, 'jobs'), 
      where('category', '==', categoryName),
      orderBy('createdAt', 'desc')
    );
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const jobData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Job));
      setJobs(jobData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `jobs/${catSlug}`);
    });
    
    return unsubscribe;
  }, [categoryName]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-20">
      <div className="lg:col-span-8 space-y-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
          <h1 className="text-2xl font-sora font-extrabold text-primary">{categoryName}</h1>
          <p className="text-gray-500 text-xs mt-1 uppercase font-bold tracking-wider">Browsing latest notifications and career updates</p>
        </div>

        <div className="space-y-3">
          {jobs.map((job) => (
            <Link key={job.id} to={`/job/${job.slug}`} className="block bg-white border border-gray-200 rounded-lg p-4 transition hover:border-gray-300 job-card-shadow flex justify-between items-start group">
              <div className="flex-grow">
                <div className="text-[10px] font-bold text-gray-500 uppercase mb-1">{job.organization}</div>
                <h3 className="font-sora font-bold text-sm text-primary leading-tight group-hover:text-accent transition-colors">{job.title}</h3>
                <div className="flex flex-wrap gap-2 mt-2">
                  <span className="bg-blue-50 text-blue-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Qualification: {job.qualification}</span>
                  <span className="bg-green-50 text-green-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Vacancies: {job.vacancies}</span>
                </div>
              </div>
              <div className="flex flex-col items-end ml-4 gap-2">
                <div className="text-[10px] text-gray-400 font-medium">Last Date: <span className="text-red-500 font-bold">{job.importantDates.end || 'TBA'}</span></div>
                <button className="bg-accent text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-red-700 transition group-hover:scale-105 transform">Details</button>
              </div>
            </Link>
          ))}
          {jobs.length === 0 && (
            <div className="bg-white p-20 text-center rounded-xl border">
              <p className="text-gray-400 font-bold">No notifications found in this category.</p>
              <Link to="/" className="text-accent text-xs font-bold hover:underline mt-2 inline-block">Return to Dashboard</Link>
            </div>
          )}
        </div>
      </div>

      <aside className="lg:col-span-4 space-y-6">
        <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
          <h3 className="font-sora font-bold text-xs text-primary mb-2">📢 Stay Notified</h3>
          <a href="#" className="flex items-center gap-3 bg-[#0088cc] text-white p-2.5 rounded hover:opacity-90 transition">
            <Send className="h-5 w-5" />
            <div className="text-[11px] font-bold">Telegram Join</div>
          </a>
          <a href="#" className="flex items-center gap-3 bg-[#25D366] text-white p-2.5 rounded hover:opacity-90 transition">
            <MessageSquare className="h-5 w-5" />
            <div className="text-[11px] font-bold">WhatsApp Channel</div>
          </a>
        </div>
      </aside>
    </div>
  );
}
