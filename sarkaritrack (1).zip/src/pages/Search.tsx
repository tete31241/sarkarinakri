import React from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { collection, query, where, getDocs, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Job } from '../types';
import { Search as SearchIcon, ChevronRight } from 'lucide-react';

export default function Search() {
  const [searchParams] = useSearchParams();
  const q = searchParams.get('q') || '';
  const [jobs, setJobs] = React.useState<Job[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const fetchJobs = async () => {
      setLoading(true);
      try {
        // Simple search: get latest jobs and filter in memory
        // Firestore doesn't support complex full-text search without Algolia/Elastic
        const jobsRef = collection(db, 'jobs');
        const querySnap = await getDocs(query(jobsRef, orderBy('createdAt', 'desc')));
        const allJobs = querySnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Job));
        
        const filtered = allJobs.filter(job => 
          job.title.toLowerCase().includes(q.toLowerCase()) ||
          job.organization.toLowerCase().includes(q.toLowerCase()) ||
          job.content.toLowerCase().includes(q.toLowerCase())
        );
        
        setJobs(filtered);
      } catch (error) {
        console.error("Search error:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchJobs();
  }, [q]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6 pb-20">
      <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
        <h1 className="text-2xl font-sora font-extrabold text-primary flex items-center gap-3">
          <SearchIcon className="h-6 w-6 text-accent" />
          Search Results: <span className="text-accent">{q}</span>
        </h1>
        <p className="text-gray-500 text-xs mt-1 uppercase font-bold tracking-wider">
          Found {jobs.length} relevant notifications
        </p>
      </div>

      <div className="space-y-3">
        {jobs.map((job) => (
          <Link 
            key={job.id} 
            to={`/job/${job.slug}`} 
            className="block bg-white border border-gray-200 rounded-lg p-4 transition hover:border-gray-300 job-card-shadow flex justify-between items-start group"
          >
            <div className="flex-grow">
              <div className="text-[10px] font-bold text-gray-500 uppercase mb-1">{job.organization}</div>
              <h3 className="font-sora font-bold text-sm text-primary leading-tight group-hover:text-accent transition-colors">{job.title}</h3>
              <div className="flex flex-wrap gap-2 mt-2">
                <span className="bg-blue-50 text-blue-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Qualification: {job.qualification}</span>
                <span className="bg-green-50 text-green-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Vacancies: {job.vacancies}</span>
              </div>
            </div>
            <div className="flex flex-col items-end ml-4 gap-2">
              <div className="text-[10px] text-gray-400 font-medium">Last Date: <span className="text-red-500 font-bold">{job.importantDates.end || 'TBA'}</span></div>
              <button className="bg-accent text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-red-700 transition">View Details</button>
            </div>
          </Link>
        ))}
        {jobs.length === 0 && (
          <div className="bg-white p-20 text-center rounded-xl border">
            <SearchIcon className="h-12 w-12 text-gray-200 mx-auto mb-4" />
            <p className="text-gray-400 font-bold">No notifications found matching your search.</p>
            <Link to="/" className="text-accent text-xs font-bold hover:underline mt-2 inline-block">Return to Dashboard</Link>
          </div>
        )}
      </div>
    </div>
  );
}
