/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { collection, query, orderBy, limit, onSnapshot } from 'firebase/firestore';
import { db, handleFirestoreError } from '../lib/firebase';
import { Job, OperationType } from '../types';
import { Link } from 'react-router-dom';
import { Briefcase, FileText, Award, Calendar, ChevronRight, Send, MessageSquare, TrendingUp } from 'lucide-react';

export default function Home() {
  const [jobs, setJobs] = React.useState<Job[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    const q = query(collection(db, 'jobs'), orderBy('createdAt', 'desc'), limit(50));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const jobData = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Job));
      setJobs(jobData);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'jobs');
    });
    return unsubscribe;
  }, []);

  const categories = [
    { title: "Central Govt", icon: "🏛", count: "12,450 posts", path: "/category/central-govt" },
    { title: "State Govt", icon: "🗺", count: "38,200 posts", path: "/category/state-govt" },
    { title: "Banking", icon: "🏦", count: "8,930 posts", path: "/category/banking" },
    { title: "Railway", icon: "🚂", count: "35,281 posts", path: "/category/railway" },
    { title: "SSC", icon: "📋", count: "17,727 posts", path: "/category/ssc" },
    { title: "UPSC", icon: "🎓", count: "1,105 posts", path: "/category/upsc" },
  ];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
      </div>
    );
  }

  const latestJobs = jobs.filter(j => j.category === "Latest Jobs");
  const results = jobs.filter(j => j.category === "Result");
  const admitCards = jobs.filter(j => j.category === "Admit Card");

  return (
    <div className="space-y-6">
      {/* Ticker */}
      <div className="bg-[#FEF3C7] border-b border-[#FDE68A] py-1.5 px-4 flex items-center gap-3 overflow-hidden">
        <span className="bg-accent text-white text-[10px] font-bold px-2 py-0.5 rounded animate-pulse">🔴 LIVE</span>
        <div className="flex-grow overflow-hidden whitespace-nowrap">
          <p className="ticker-scroll text-xs font-medium text-[#92400E]">
            {jobs.slice(0, 5).map(j => `🔔 ${j.title} | `).join('')}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 pb-12">
        {/* Main Content Area */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Stats Bar */}
          <div className="bg-primary text-white rounded-lg p-4 grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center border-r border-white/20 last:border-0">
              <div className="text-lg font-bold text-accent-gold font-sora">4,28,191</div>
              <div className="text-[10px] text-white/70 uppercase">Total Vacancies</div>
            </div>
            <div className="text-center border-r border-white/20 last:border-0">
              <div className="text-lg font-bold text-accent-gold font-sora">{jobs.length}</div>
              <div className="text-[10px] text-white/70 uppercase">Active Posts</div>
            </div>
            <div className="text-center border-r border-white/20 last:border-0">
              <div className="text-lg font-bold text-accent-gold font-sora">{results.length}</div>
              <div className="text-[10px] text-white/70 uppercase">New Results</div>
            </div>
            <div className="text-center border-r border-white/20 last:border-0">
              <div className="text-lg font-bold text-accent-gold font-sora">{admitCards.length}</div>
              <div className="text-[10px] text-white/70 uppercase">Admit Cards</div>
            </div>
          </div>

          {/* Quick Category Grid */}
          <div className="grid grid-cols-3 md:grid-cols-6 gap-2">
            {categories.map((cat) => (
              <Link key={cat.title} to={cat.path} className="bg-white border border-gray-200 rounded-lg p-3 text-center hover:bg-blue-50 hover:border-primary transition group">
                <div className="text-xl mb-1">{cat.icon}</div>
                <div className="text-[11px] font-bold text-primary font-sora leading-tight group-hover:text-accent transition-colors">{cat.title}</div>
              </Link>
            ))}
          </div>

          {/* Jobs List */}
          <section>
            <div className="flex items-center justify-between border-b-2 border-primary mb-4 pb-2">
              <h2 className="font-sora font-bold text-sm text-primary flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-accent" /> Latest Government Jobs 2026
              </h2>
              <Link to="/category/latest-jobs" className="text-[10px] font-bold text-accent border border-accent px-2 py-0.5 rounded hover:bg-accent hover:text-white transition">View All</Link>
            </div>

            <div className="space-y-3">
              {latestJobs.map((job) => (
                <Link key={job.id} to={`/job/${job.slug}`} className="block bg-white border border-gray-200 rounded-lg p-4 transition hover:border-gray-300 job-card-shadow flex justify-between items-start group">
                  <div className="flex-grow">
                    <div className="text-[10px] font-bold text-gray-500 uppercase mb-1">{job.organization}</div>
                    <h3 className="font-sora font-bold text-sm text-primary leading-tight group-hover:text-accent transition-colors">{job.title}</h3>
                    <div className="flex flex-wrap gap-2 mt-2">
                      <span className="bg-blue-50 text-blue-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Qualification: {job.qualification}</span>
                      <span className="bg-green-50 text-green-700 text-[10px] font-bold px-1.5 py-0.5 rounded whitespace-nowrap">Vacancies: {job.vacancies}</span>
                    </div>
                  </div>
                  <div className="flex flex-col items-end ml-4 gap-2">
                    <div className="text-[10px] text-gray-400 font-medium">Last Date: <span className="text-red-500 font-bold">{job.importantDates.end || 'TBA'}</span></div>
                    <button className="bg-accent text-white text-[10px] font-bold px-3 py-1.5 rounded hover:bg-red-700 transition">Apply Now</button>
                  </div>
                </Link>
              ))}
              {latestJobs.length === 0 && <div className="text-center py-12 text-gray-400">No new job openings found.</div>}
            </div>
          </section>
        </div>

        {/* Sidebar */}
        <aside className="lg:col-span-4 space-y-6">
          {/* Subscription */}
          <div className="bg-gradient-to-br from-primary to-primary-light rounded-lg p-5 text-white shadow-xl">
            <h3 className="font-sora font-bold text-sm mb-1 flex items-center gap-2">📬 Get Free Job Alerts</h3>
            <p className="text-[11px] text-white/70 mb-3 leading-relaxed">Be the first to know about new government job notifications</p>
            <div className="flex gap-2">
              <input type="email" placeholder="Enter email" className="flex-grow bg-white rounded px-3 py-2 text-xs text-gray-800 outline-none" />
              <button className="bg-accent px-3 py-2 text-[11px] font-bold rounded hover:bg-red-700 transition">Subscribe</button>
            </div>
          </div>

          {/* Results Sidebar */}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="bg-green-600 px-4 py-2.5 text-white font-sora font-bold text-xs uppercase flex items-center justify-between">
              <span>📊 Latest Results</span>
              <Award className="h-3.5 w-3.5 opacity-70" />
            </div>
            <div className="divide-y divide-gray-100">
              {results.slice(0, 8).map(result => (
                <Link key={result.id} to={`/job/${result.slug}`} className="block px-4 py-3 hover:bg-gray-50 transition group">
                  <div className="flex justify-between items-start gap-3">
                    <span className="text-[12px] font-medium text-gray-800 line-clamp-2 leading-snug group-hover:text-accent">{result.title}</span>
                    <span className="bg-accent text-white text-[9px] font-bold px-1 rounded animate-pulse shrink-0">NEW</span>
                  </div>
                </Link>
              ))}
              {results.length === 0 && <div className="p-6 text-center text-xs text-gray-400">Updating...</div>}
            </div>
          </div>

          {/* Admit Cards Sidebar */}
          <div className="bg-white border border-gray-200 rounded-lg overflow-hidden shadow-sm">
            <div className="bg-[#D97706] px-4 py-2.5 text-white font-sora font-bold text-xs uppercase flex items-center justify-between">
              <span>🪪 Admit Cards</span>
              <FileText className="h-3.5 w-3.5 opacity-70" />
            </div>
            <div className="divide-y divide-gray-100">
              {admitCards.slice(0, 8).map(card => (
                <Link key={card.id} to={`/job/${card.slug}`} className="block px-4 py-3 hover:bg-gray-50 transition group">
                  <div className="flex justify-between items-start gap-3">
                    <span className="text-[12px] font-medium text-gray-800 line-clamp-2 leading-snug group-hover:text-accent">{card.title}</span>
                    <span className="bg-accent text-white text-[9px] font-bold px-1 rounded shrink-0">NEW</span>
                  </div>
                </Link>
              ))}
              {admitCards.length === 0 && <div className="p-6 text-center text-xs text-gray-400">Updating...</div>}
            </div>
          </div>

          {/* Social Community */}
          <div className="bg-white border border-gray-200 rounded-lg p-4 space-y-3">
            <h3 className="font-sora font-bold text-xs text-primary mb-2">📢 Join Our Community</h3>
            <a href="#" className="flex items-center gap-3 bg-[#0088cc] text-white p-2.5 rounded hover:opacity-90 transition">
              <Send className="h-5 w-5" />
              <div className="text-[11px] font-bold">Telegram – 2.4L+ Members</div>
            </a>
            <a href="#" className="flex items-center gap-3 bg-[#25D366] text-white p-2.5 rounded hover:opacity-90 transition">
              <MessageSquare className="h-5 w-5" />
              <div className="text-[11px] font-bold">WhatsApp Channel Alerts</div>
            </a>
          </div>

        </aside>
      </div>
    </div>
  );
}
