/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { db, auth, handleFirestoreError } from '../lib/firebase';
import { collection, doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { Job, OperationType } from '../types';
import slugify from 'slugify';

export default function Admin() {
  const [user, setUser] = React.useState(auth.currentUser);
  const [form, setForm] = React.useState<Partial<Job>>({
    title: '',
    organization: '',
    vacancies: '',
    qualification: '',
    salary: '',
    ageLimit: '',
    category: 'Latest Jobs',
    importantDates: { start: '', end: '', examDate: '' },
    links: { applyLink: '', pdfLink: '', officialWebsite: '' },
    content: '',
    isTrending: false,
    state: ''
  });
  const [status, setStatus] = React.useState<{ type: 'success' | 'error', message: string } | null>(null);

  React.useEffect(() => {
    return auth.onAuthStateChanged((u) => setUser(u));
  }, []);

  if (!user || user.email !== "bimalm20035@gmail.com") {
    return (
      <div className="text-center py-20">
        <h1 className="text-2xl font-bold text-red-600">Access Denied</h1>
        <p className="text-gray-600 mt-2">Only administrators can access this page.</p>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus(null);
    try {
      const slug = slugify(form.title || '', { lower: true, strict: true }) + '-' + Math.floor(Math.random() * 1000);
      const newJobId = doc(collection(db, 'jobs')).id;
      const jobData = {
        ...form,
        slug,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await setDoc(doc(db, 'jobs', newJobId), jobData);
      setStatus({ type: 'success', message: 'Job posted successfully!' });
      // Reset form partially if needed
    } catch (error) {
      setStatus({ type: 'error', message: 'Failed to post job. Check console.' });
      handleFirestoreError(error, OperationType.CREATE, 'jobs');
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (name.includes('.')) {
      const [parent, child] = name.split('.');
      setForm(prev => ({
        ...prev,
        [parent]: {
          ...(prev[parent as keyof typeof prev] as any),
          [child]: value
        }
      }));
    } else {
      setForm(prev => ({ ...prev, [name]: type === 'checkbox' ? (e.target as any).checked : value }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto bg-white p-8 rounded-2xl shadow-sm border">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Admin Dashboard - Post New Job</h1>
      
      {status && (
        <div className={`p-4 rounded-lg mb-6 ${status.type === 'success' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
          {status.message}
        </div>
      )}

      <form onSubmit={handleSubmit} className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="md:col-span-2">
          <label className="block text-sm font-bold text-gray-700 mb-1">Job Title</label>
          <input name="title" value={form.title} onChange={handleChange} required className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., SSC CGL Recruitment 2026" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Organization</label>
          <input name="organization" value={form.organization} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., Staff Selection Commission" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Category</label>
          <select name="category" value={form.category} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500">
            <option>Latest Jobs</option>
            <option>Admit Card</option>
            <option>Result</option>
            <option>Answer Key</option>
            <option>Syllabus</option>
            <option>Upcoming Exam</option>
          </select>
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Vacancies</label>
          <input name="vacancies" value={form.vacancies} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., 12000" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Qualification</label>
          <input name="qualification" value={form.qualification} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., Graduation" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Salary</label>
          <input name="salary" value={form.salary} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., 35,400 - 1,12,400" />
        </div>

        <div>
          <label className="block text-sm font-bold text-gray-700 mb-1">Age Limit</label>
          <input name="ageLimit" value={form.ageLimit} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" placeholder="e.g., 18 - 32 Years" />
        </div>

        <div className="md:col-span-2 grid grid-cols-1 md:grid-cols-3 gap-4 bg-gray-50 p-4 rounded-xl">
           <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Start Date</label>
              <input name="importantDates.start" value={form.importantDates?.start} onChange={handleChange} type="date" className="w-full border rounded-lg p-2" />
           </div>
           <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Last Date</label>
              <input name="importantDates.end" value={form.importantDates?.end} onChange={handleChange} type="date" className="w-full border rounded-lg p-2" />
           </div>
           <div>
              <label className="block text-xs font-bold text-gray-400 mb-1 uppercase">Exam Date</label>
              <input name="importantDates.examDate" value={form.importantDates?.examDate} onChange={handleChange} type="date" className="w-full border rounded-lg p-2" />
           </div>
        </div>

        <div className="md:col-span-2 space-y-4">
           <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">Application URL</label>
              <input name="links.applyLink" value={form.links?.applyLink} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" />
           </div>
           <div>
              <label className="block text-sm font-bold text-gray-700 mb-1">PDF Notification URL</label>
              <input name="links.pdfLink" value={form.links?.pdfLink} onChange={handleChange} className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500" />
           </div>
        </div>

        <div className="md:col-span-2">
          <label className="block text-sm font-bold text-gray-700 mb-1">Detailed Content (HTML/Rich Text)</label>
          <textarea 
            name="content" 
            value={form.content} 
            onChange={handleChange} 
            rows={10} 
            className="w-full border rounded-lg p-2.5 focus:ring-2 focus:ring-blue-500 font-mono text-sm" 
            placeholder="<p>Enter detailed info here...</p>" 
          />
        </div>

        <div className="md:col-span-2">
          <button type="submit" className="w-full bg-blue-600 text-white font-bold py-4 rounded-xl hover:bg-blue-700 transition shadow-lg shadow-blue-200">
            Publish Post
          </button>
        </div>
      </form>
    </div>
  );
}
