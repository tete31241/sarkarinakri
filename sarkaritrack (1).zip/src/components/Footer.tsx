/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-white font-bold mb-4">SarkariTrack</h3>
            <p className="text-sm">Your trusted portal for government job notifications, results, and career updates.</p>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Exams</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-blue-400">SSC</a></li>
              <li><a href="#" className="hover:text-blue-400">UPSC</a></li>
              <li><a href="#" className="hover:text-blue-400">Banking</a></li>
              <li><a href="#" className="hover:text-blue-400">Railways</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Helpful Links</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-blue-400">About Us</a></li>
              <li><a href="#" className="hover:text-blue-400">Contact Us</a></li>
              <li><a href="#" className="hover:text-blue-400">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-blue-400">Disclaimer</a></li>
            </ul>
          </div>
          <div>
            <h4 className="text-white font-semibold mb-4">Follow Us</h4>
            <div className="flex gap-4">
              <span className="text-xs">FB</span>
              <span className="text-xs">TW</span>
              <span className="text-xs">TG</span>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-center text-xs">
          © {new Date().getFullYear()} SarkariTrack. Designed for career success.
        </div>
      </div>
    </footer>
  );
}
