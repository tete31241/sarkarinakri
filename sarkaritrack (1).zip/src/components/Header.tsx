/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, Bell, Menu, X, User, Phone, MessageSquare, Send } from 'lucide-react';
import { auth } from '../lib/firebase';
import { signInWithPopup, GoogleAuthProvider, signOut } from 'firebase/auth';

export default function Header() {
  const [isOpen, setIsOpen] = React.useState(false);
  const [user, setUser] = React.useState(auth.currentUser);
  const [searchQuery, setSearchQuery] = React.useState('');
  const navigate = useNavigate();

  React.useEffect(() => {
    return auth.onAuthStateChanged((u) => setUser(u));
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleLogin = async () => {
    try {
      await signInWithPopup(auth, new GoogleAuthProvider());
    } catch (error) {
      console.error("Login failed:", error);
    }
  };

  const navLinks = [
    { title: "🏛 Central Govt", path: "/category/central-govt" },
    { title: "🗺 State Govt", path: "/category/state-govt" },
    { title: "🏦 Banking", path: "/category/banking" },
    { title: "🚂 Railway", path: "/category/railway" },
    { title: "📋 SSC", path: "/category/ssc" },
    { title: "🎓 UPSC", path: "/category/upsc" },
    { title: "📝 Results", path: "/category/result" },
    { title: "🪪 Admit Card", path: "/category/admit-card" },
  ];

  return (
    <header className="z-50 sticky top-0 shadow-lg">
      {/* Top Header */}
      <div className="bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between gap-4">
          <Link to="/" className="flex items-center gap-2 font-sora font-bold text-lg whitespace-nowrap">
            <div className="bg-accent text-white p-1 rounded text-xs">🏛</div>
            <span>Sarkari<span className="text-accent-gold">Track</span>.com</span>
          </Link>

          <form onSubmit={handleSearch} className="hidden md:flex flex-1 max-w-lg bg-white rounded overflow-hidden">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-grow px-3 py-1.5 text-gray-800 text-sm outline-none"
              placeholder="Search jobs, results, admit cards..."
            />
            <button type="submit" className="bg-accent px-4 py-1.5 text-white text-sm font-bold hover:bg-red-700 transition">
              Search
            </button>
          </form>

          <div className="hidden lg:flex items-center gap-4 text-[11px] font-bold text-white/80">
            <a href="#" className="hover:text-white flex items-center gap-1"><Phone className="h-3 w-3" /> App</a>
            <a href="#" className="hover:text-white flex items-center gap-1"><Send className="h-3 w-3" /> Telegram</a>
            <a href="#" className="hover:text-white flex items-center gap-1"><MessageSquare className="h-3 w-3" /> WhatsApp</a>
            {user ? (
              <div className="flex items-center gap-2">
                <button onClick={() => signOut(auth)} className="bg-white/10 px-2 py-1 rounded hover:bg-white/20">Logout</button>
                {user.email === "bimalm20035@gmail.com" && <Link to="/admin" className="text-accent-gold">Admin</Link>}
              </div>
            ) : (
              <button onClick={handleLogin} className="hover:text-white">Sign In</button>
            )}
          </div>

          <button onClick={() => setIsOpen(!isOpen)} className="lg:hidden text-white">
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>
      </div>

      {/* Main Navigation */}
      <nav className="bg-primary-light overflow-x-auto border-t border-white/10 hidden md:block">
        <div className="max-w-7xl mx-auto px-4 flex">
          <Link to="/" className="px-4 py-2.5 text-xs font-bold font-sora text-white border-b-2 border-accent-gold bg-white/10">🏠 Home</Link>
          {navLinks.map((link) => (
            <Link
              key={link.title}
              to={link.path}
              className="px-4 py-2.5 text-xs font-bold font-sora text-white/90 hover:text-white hover:bg-white/10 border-b-2 border-transparent hover:border-accent-gold transition-all whitespace-nowrap"
            >
              {link.title}
            </Link>
          ))}
        </div>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="lg:hidden bg-primary text-white border-t border-white/10 p-4 space-y-4">
          <form onSubmit={handleSearch} className="flex bg-white rounded overflow-hidden">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="flex-grow px-3 py-2 text-gray-800 text-sm outline-none"
              placeholder="Search..."
            />
            <button className="bg-accent px-4 py-2 text-white text-sm font-bold">Search</button>
          </form>
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <Link key={link.title} to={link.path} onClick={() => setIsOpen(false)} className="py-2 text-xs font-bold font-sora text-white/80 hover:text-white">{link.title}</Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}
