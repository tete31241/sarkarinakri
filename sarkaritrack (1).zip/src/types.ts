/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Job {
  id: string;
  title: string;
  organization: string;
  vacancies: string;
  qualification: string;
  salary: string;
  ageLimit: string;
  category: "Latest Jobs" | "Admit Card" | "Result" | "Answer Key" | "Syllabus" | "Upcoming Exam";
  importantDates: {
    start?: string;
    end?: string;
    examDate?: string;
  };
  links: {
    applyLink?: string;
    pdfLink?: string;
    officialWebsite?: string;
  };
  content: string;
  slug: string;
  createdAt: string;
  isTrending: boolean;
  state?: string;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  }
}
