/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import JobDetail from './pages/JobDetail';
import CategoryPage from './pages/CategoryPage';
import Admin from './pages/Admin';
import Search from './pages/Search';

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/job/:slug" element={<JobDetail />} />
          <Route path="/category/:catSlug" element={<CategoryPage />} />
          <Route path="/search" element={<Search />} />
          <Route path="/admin" element={<Admin />} />
        </Routes>
      </Layout>
    </Router>
  );
}
